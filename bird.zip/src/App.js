import "./App.css";
import BirdList from "./component/BirdList";
import { React, useEffect, useState, useRef } from "react";
import axios from "axios";
import SidBar from "./component/SidBar";
function App() {
  const [birdArray, setBirdArray] = useState([]);
  useEffect(() => {
    fetchData();
  }, []);
  const fetchData = () => {
    axios({
      method: "GET",
      url: `https://zapari.any.do/birds/5`,
    }).then((res) => {
      setBirdArray((prevArray) => [...prevArray, ...res.data.items]);
    });
  };

  return (
    <div className="app">
      <div className="container">
        <SidBar className="sid-bar" birdArray={birdArray}></SidBar>

        <BirdList
          className="main-view"
          fetchData={fetchData}
          birdArray={birdArray}
        ></BirdList>
      </div>
    </div>
  );
}

export default App;
