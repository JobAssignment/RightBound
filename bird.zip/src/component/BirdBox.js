import { React, useEffect, useState } from "react";

import "./style/birdbox.css";
const googleApiKey = "AIzaSyCTVoXmQT4Gvco8NhgExSjPVVeapFqiJ7Q";
const googleMap = "https://maps.googleapis.com/maps/api/staticmap";
function BirdBox(props) {
  const [mapUrl, setMapUrl] = useState({});
  useEffect(() => {
    const langLat = `${props.bird.location.lat},${props.bird.location.lng}`;
    const url = `${googleMap}?center=${langLat}&key=${googleApiKey}&size=600x300`;
    setMapUrl(url);
    // console.log(url);
  }, []);
  return (
    <div className="bird-container">
      <div className="row1">
        <h1>{props.bird.name}</h1>
        <audio controls>
          <source src={props.bird.sound} />
        </audio>
      </div>
      <div className="row2">
        <img className="img-container" src={props.bird.image}></img>
        <img className="img-container" src={mapUrl}></img>
      </div>
    </div>
  );
}

export default BirdBox;
