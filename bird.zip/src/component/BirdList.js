import { React, useEffect, useState, useRef } from "react";
import axios from "axios";
import BirdBox from "./BirdBox";

const birdApi = "https://zapari.any.do/birds/20";
export default function BirdList(props) {
  useEffect(() => {
    return () => {
      observer.current.disconnect();
    };
  });
  const observer = useRef();

  const lastBirdRef = (node) => {
    const options = {
      root: document.querySelector("#scrollArea"),
      rootMargin: "1px",
      threshold: 0.7,
    };
    observer.current = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting) {
        console.log(" visable know ", entries[0]);
        props.fetchData();
      }
    });

    if (node) {
      observer.current.observe(node);
      console.log("-----------observe");
    }
  };

  return (
    <div className="bird-list">
      <p> bird List</p>
      {props.birdArray.map((bird, index) => {
        return <BirdBox key={index} bird={bird}></BirdBox>;
      })}

      <p ref={lastBirdRef}>loading ...</p>
    </div>
  );
}

{
}
