import React from "react";

export default function SidBar(props) {
  return (
    <div>
      <p> side bar</p>
      {props.birdArray.map((b, index) => {
        return (
          <div key={index}>
            <h3>{b.name}</h3>
            <img width="200px" height="200px" src={b.image}></img>
          </div>
        );
      })}
    </div>
  );
}
