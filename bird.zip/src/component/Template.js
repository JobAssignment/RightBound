import React from "react";

function Template(props) {
  return (
    <div>
      {props.last ? <p>last bird</p> : null}
      <h1>{props.bird.name}</h1>
    </div>
  );
}

export default Template;
